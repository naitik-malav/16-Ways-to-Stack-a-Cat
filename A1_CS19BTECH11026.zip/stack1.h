long long int *create_stack(long long int *, int);
long long int *push_stack(long long int *, long long int, int);
long long int *pop_stack(long long int *, int);
void print_stack(long long int array[], int);
