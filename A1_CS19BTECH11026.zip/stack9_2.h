class stack_rep { 
    public:
        int i;
        long long int *ptr;
};